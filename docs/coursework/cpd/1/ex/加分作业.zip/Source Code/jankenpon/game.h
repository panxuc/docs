#pragma warning(disable:4996)
#include <stdio.h>
#include <stdlib.h>
#define PAPER 0
#define ROCK 1
#define SCISSOR 2
#define GAME 3
#define HELP 4
#define QUIT 5
#define WIN 6
#define TIE 7
#define LOSE 8
#define ERROR 9